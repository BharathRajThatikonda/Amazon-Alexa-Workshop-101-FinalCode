
const names = {
    "horror":`The Nun and Pari and Arundathi`,
    "action":`Baahubali and Sholay and Deadpool`,
    "comedy":`The Dictator and 3 idiots and Raja the Great`
}

module.exports = {
    names
}


